﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace First
{
    public partial class LginForm : Form
    {
        public LginForm()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string userCheckCase = this.txtUsername.Text.ToUpper().Trim();
            string sql = "SELECT UPPER(username) AS username, password, role " +
                         "FROM users WHERE UPPER(username)= '" + userCheckCase +
                         "' AND password='" + this.txtPassword.Text + "';";

            Database_Access da = new Database_Access();
            DataSet ds = da.ExecuteQuery(sql);

            if (ds.Tables[0].Rows.Count == 1)
            {
                string role = ds.Tables[0].Rows[0]["role"].ToString();

                if (role == "audit")
                {
                    audit_dashboard ad = new audit_dashboard(); // normal user dashboard
                    this.Hide();
                    ad.Show();
                }
                else
                {
                    Form2 user = new Form2(); // normal user dashboard
                    this.Hide();
                    user.Show();
                }
            }
            else if (txtUsername.Text == "" && txtPassword.Text == "")
            {
                MessageBox.Show("Username and Password cannot be empty.");
            }
            else if (txtUsername.Text == "")
            {
                MessageBox.Show("Username cannot be empty.");
            }
            else if (txtPassword.Text == "")
            {
                MessageBox.Show("Password cannot be empty.");
            }
            else
            {
                MessageBox.Show("Login Failed!");
            }
        }

    }
}
